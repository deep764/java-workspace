package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

import com.model.ProductModel;
import com.model.model;

public class dao 
{
	
	public static Connection getconnect()
	{
		Connection con = null;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/webwing","root","");
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
		
	}
	// data contact us
	public static int insertdata(model m)
	{
		Connection con = UserDao.getconnect();
		int status =0;
		
		try 
		{
			PreparedStatement ps = con.prepareStatement("insert into contact(name,email,subject,message) values(?,?,?,?)");
			ps.setString(1,m.getName());
			ps.setString(2,m.getEmail());
			ps.setString(3,m.getSubject());
			ps.setString(4,m.getMessage());
			
			status = ps.executeUpdate();
			
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}
	// product data
	
	public static List<ProductModel> getAll()
	
	{
		List<ProductModel> i = new ArrayList<ProductModel>();
		try {
			
			Connection con = UserDao.getconnect();
			PreparedStatement ps= con.prepareStatement("Select * from products");
			
			ResultSet rs = (ResultSet) ps.executeQuery();
			
			while(rs.next())
			{
				ProductModel d1 = new ProductModel();
				//d1 = new ImageModel();
				d1.setP_id(rs.getInt(1));
				d1.setP_name(rs.getString(2));
				d1.setP_price(rs.getInt(3));
				d1.setP_description(rs.getString(4));
				d1.setP_image(rs.getString(5));
				i.add(d1);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return i;
	}
	
}
